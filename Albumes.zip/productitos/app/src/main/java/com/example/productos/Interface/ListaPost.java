package com.example.productos.Interface;

import com.example.productos.Models.Post;

import java.util.List;

import retrofit2.Call;
import retrofit2.http.GET;
import retrofit2.http.Query;

public interface ListaPost {
    @GET("comments")
    Call<List<Post>> find(@Query("id")String q);
}
