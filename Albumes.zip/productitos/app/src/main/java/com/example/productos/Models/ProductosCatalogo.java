package com.example.productos.Models;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;

import com.example.productos.Interface.ListaPost;
import com.example.productos.Interface.ServicioPost;
import com.example.productos.R;
import java.util.ArrayList;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class ProductosCatalogo extends AppCompatActivity {

    EditText editPalabra;
    Button btnBuscar;
    TextView txtResul;
    ListView listAlbumes;
    ArrayList<String> arrayNames;
    ArrayAdapter adapter;

    @Override
    protected void onResume() {
        super.onResume();
        setContentView(R.layout.activity_productos_catalogo);

        arrayNames = new ArrayList<String>();
        editPalabra = (EditText)findViewById(R.id.editBuscar);
        btnBuscar = (Button)findViewById(R.id.btnBuscar);
        txtResul = (TextView)findViewById(R.id.txtResultado);
        listAlbumes = (ListView) findViewById(R.id.listAlbumes);
        listaAccion();

        adapter = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, arrayNames);


        listAlbumes.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> AdapterView, View view, int position, long l) {
                Intent intent = new Intent(ProductosCatalogo.this, Productos_Infor.class);
                intent.putExtra("NOMBRE", arrayNames.get(position));
                startActivity(intent);
            }
        });

        btnBuscar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                arrayNames.clear();
                resultado(editPalabra.getText().toString());
            }
        });

    }

    public void resultado(String q){
        Retrofit retrofit = new Retrofit.Builder()

                .baseUrl("https://jsonplaceholder.typicode.com/")
                .addConverterFactory(GsonConverterFactory.create())
                .build();
        ServicioPost postService = retrofit.create(ServicioPost.class);
        Call<List<Post>> call = postService.find(q);
        call.enqueue(new Callback<List<Post>>() {
            @Override
            public void onResponse(Call<List<Post>> call, Response<List<Post>> response) {
                List<Post> postsList = response.body();
                for (Post p: postsList){
                    String n = p.getName();
                    arrayNames.add(n);
                }
                listAlbumes.setAdapter(adapter);
            }

            @Override
            public void onFailure(Call<List<Post>> call, Throwable t) {
                txtResul.setText(t.getMessage());
            }
        });
    }
    public  void listaAccion(){
        for (int i = 1; i <= 50; i++ ){
            lista(i+"");
        }
    }
    public void lista(String q){
        Retrofit retrofit = new Retrofit.Builder()

                .baseUrl("https://jsonplaceholder.typicode.com/")
                .addConverterFactory(GsonConverterFactory.create())
                .build();
        ListaPost postServiceLista = retrofit.create(  ListaPost.class);
        Call<List<Post>> call = postServiceLista.find(q);
        call.enqueue(new Callback<List<Post>>() {
            @Override
            public void onResponse(Call<List<Post>> call, Response<List<Post>> response) {
                List<Post> postsList = response.body();
                for (Post p: postsList){
                    String n = p.getName();
                    arrayNames.add(n);
                }
                listAlbumes.setAdapter(adapter);
            }

            @Override
            public void onFailure(Call<List<Post>> call, Throwable t) {
                txtResul.setText(t.getMessage());
            }
        });
    }
}