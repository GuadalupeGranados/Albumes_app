package com.example.productos.Models;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;

public class BaseDatos extends SQLiteOpenHelper {
    private static final String NOMBRE_BD = "albumes";
    private static final int VERSION_BD = 1;
    private static final String TABLA_ALBUMES = "CREATE TABLE ALBUMES(NOMBRE TEXT PRIMARY KEY, DESCRIPCION TEXT, TELEFONO TEXT)";
    public BaseDatos (Context context){
        super(context, NOMBRE_BD, null, VERSION_BD);
    }

    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {
        sqLiteDatabase.execSQL(TABLA_ALBUMES);
    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {
        sqLiteDatabase.execSQL("DROP TABLE IF EXISTS " + TABLA_ALBUMES);
        sqLiteDatabase.execSQL(TABLA_ALBUMES);
    }
    public void agregarPre(){
        SQLiteDatabase bd=getWritableDatabase();
        if (bd!=null){
            bd.execSQL("delete from ALBUMES");
            bd.execSQL("INSERT INTO ALBUMES VALUES('PINK FLOYD','MUSICA PARA ESCUCHAR EN CUALQUIER LUGAR','55-1925-8967')");
            bd.execSQL("INSERT INTO ALBUMES VALUES('RAMNSTEIN', 'MUSICA SOLO PARA AMANTES DEL ROCK', '55-4534-1678')");
            bd.close();
        }
    }


    public void agregarAlbum(String nombre,  String descripcion, String telefono){
        SQLiteDatabase bd=getWritableDatabase();
        if (bd!=null){
            bd.execSQL("INSERT INTO ALBUMES VALUES('"+nombre+"','"+descripcion+"', '"+telefono+"')");
            bd.close();
        }
    }

    public void eliminarAlbumes(String nombre){
        SQLiteDatabase bd=getWritableDatabase();
        if (bd!=null){
            bd.execSQL("DELETE FROM ALBUMES WHERE nombre='"+nombre+"'");
            bd.close();
        }
    }
    public ArrayList datos_listAlbumes(){
        ArrayList<String> lista = new ArrayList<>();
        SQLiteDatabase bd = this.getReadableDatabase();
        String q = "SELECT * FROM ALBUMES";
        Cursor registros = bd.rawQuery(q,null);
        if (registros.moveToFirst()){
            do {
                String albumes = registros.getString(0);
                lista.add(albumes);
            }while(registros.moveToNext());
        }
        return lista;
    }
    public  String[] buscarAlbum(String buscar) {
        String[] datos = new String[4];
        SQLiteDatabase bd = this.getWritableDatabase();
        String q = "SELECT * FROM ALBUMES WHERE NOMBRE ='"+buscar+"'";
        Cursor registros = bd.rawQuery(q,null);
        if (registros.moveToFirst()){
            for (int i = 0; i <= 3; i++) {
                datos[i] = registros.getString(i);
            }
        }
        return datos;
    }
}


