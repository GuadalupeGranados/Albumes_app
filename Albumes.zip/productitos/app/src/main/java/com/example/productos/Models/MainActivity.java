package com.example.productos.Models;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.example.productos.R;

public class MainActivity extends AppCompatActivity {

    EditText editUsuario, editContra;
    TextView txtIncoUsu, txtIncoContra;
    Button btnIniciar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        editUsuario = (EditText)findViewById(R.id.editUsuario);
        editContra = (EditText)findViewById(R.id.editContra);
        txtIncoUsu = (TextView)findViewById(R.id.txtIncoUsu);
        txtIncoContra = (TextView)findViewById(R.id.txtIncoContra);
        btnIniciar = (Button)findViewById(R.id.btnIniciar);


        btnIniciar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (editUsuario.getText().toString().isEmpty() || editContra.getText().toString().isEmpty()){
                    if (editUsuario.getText().toString().isEmpty()) txtIncoUsu.setText(" Llenar usuario");
                    if (editContra.getText().toString().isEmpty()) txtIncoContra.setText("Llena contraseña");
                    Toast.makeText(MainActivity.this, "Hay campos sin llenar", Toast.LENGTH_LONG).show();
                }else{
                    if (editUsuario.getText().toString().equals("Album1") && editContra.getText().toString().equals("1122")) {
                        Toast.makeText(MainActivity.this, "Bienvenido", Toast.LENGTH_LONG).show();
                        Intent intent = new Intent(MainActivity.this, ProductosCatalogo.class);
                        startActivity(intent);
                        editUsuario.setText("");
                        editContra.setText("");
                    }else {
                        if (editUsuario.getText().toString().equals("Album1")) { } else { txtIncoUsu.setText("Usuario incorrecto"); }
                        if (editContra.getText().toString().equals("1122")) { } else  { txtIncoContra.setText("Contraseña incorrecta"); }
                        Toast.makeText(MainActivity.this, "Usuario o contraseña inválidos", Toast.LENGTH_LONG).show();
                    }
                }
            }
        });

    }
}