package com.example.productos.Models;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import com.example.productos.Compra;
import com.example.productos.Interface.ServicioPost;
import com.example.productos.R;

import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class Productos_Infor extends AppCompatActivity {

    TextView txtNombre, txtNumero,txtDescripcion, txtInfo ;
    Button btnComprar;
    ImageButton btnLlamar;
    private final int PHONE_CALL_CODE = 100;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_productos__infor);

        txtNombre = (TextView)findViewById(R.id.txtNombre);
        txtDescripcion = (TextView)findViewById(R.id.txtDescripcion);
        txtNumero = (TextView)findViewById(R.id.txtNumero);
        txtInfo = (TextView)findViewById(R.id.txtInfo);
       btnComprar = (Button)findViewById(R.id.btnComprar);
        btnLlamar = (ImageButton)findViewById(R.id.btnLlamar);


        Bundle bundle = getIntent().getExtras();
        String nombre = bundle.getString("NOMBRE");
        resultado(nombre);

        btnComprar.setOnClickListener(new View.OnClickListener() {
           @Override
            public void onClick(View v) {
               try (BaseDatos bd = new BaseDatos(getApplicationContext())) {

                 bd.agregarAlbum(txtNombre.getText().toString(), txtDescripcion.getText().toString(),  txtNumero.getText().toString());
                    Toast.makeText(getApplicationContext(), "Felicidades por tu nuevo álbum", Toast.LENGTH_SHORT).show();
                   Intent intent = new Intent(Productos_Infor.this, Compra.class);
                    startActivity(intent);
                    finish();
                }
            }
        });

        btnLlamar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String tel = txtNumero.getText().toString();
                if (tel != null){
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M){
                        requestPermissions(new String[]{Manifest.permission.CALL_PHONE},PHONE_CALL_CODE);
                    }else{
                        versionAntigua(tel);
                    }
                }
            }

            private void versiomNueva(){

            }
            private  void versionAntigua(String tel){
                Intent intentLlamar = new Intent(Intent.ACTION_CALL, Uri.parse("tel:"+tel));
                if (verificarPermisos(Manifest.permission.CALL_PHONE)){
                    startActivity(intentLlamar);
                }else{
                    Toast.makeText(Productos_Infor.this, "Active el permiso de llamadas", Toast.LENGTH_SHORT);
                }
            }
        });

    }

    public void resultado(String q){
        Retrofit retrofit = new Retrofit.Builder()

                .baseUrl("https://jsonplaceholder.typicode.com/")
                .addConverterFactory(GsonConverterFactory.create())
                .build();
        ServicioPost postService = retrofit.create(ServicioPost.class);
        Call<List<Post>> call = postService.find(q);
        call.enqueue(new Callback<List<Post>>() {
            @Override
            public void onResponse(Call<List<Post>> call, Response<List<Post>> response) {
                List<Post> ListaPost = response.body();
                for (Post p: ListaPost){
                    String nombre = p.getName();
                    String descripcion = p.getBody();
                    String telefono = "55-1925-8967";
                    txtNombre.append(nombre);
                    txtDescripcion.append(descripcion);
                    txtNumero.append(telefono);
                }
            }

            @Override
            public void onFailure(Call<List<Post>> call, Throwable t) {
                txtInfo.setText(t.getMessage());
            }
        });
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        switch (requestCode){
            case PHONE_CALL_CODE:
                String permission = permissions[0];
                int result = grantResults[0];
                if (permission.equals(Manifest.permission.CALL_PHONE)){

                    if (result == PackageManager.PERMISSION_GRANTED){
                        String numTel = txtNumero.getText().toString();
                        Intent llamada = new Intent(Intent.ACTION_CALL, Uri.parse("tel:" + numTel));
                        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.CALL_PHONE) != PackageManager.PERMISSION_GRANTED) return;
                        startActivity(llamada);
                    }else {
                        Toast.makeText(this, "Autoriza los permisos", Toast.LENGTH_SHORT).show();
                    }
                }
        }
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
    }

    private boolean verificarPermisos(String permiso){
        int resultado = this.checkCallingOrSelfPermission(permiso);
        return resultado == PackageManager.PERMISSION_GRANTED;
    }
}
