package com.example.productos;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;

import com.example.productos.Models.BaseDatos;

import java.util.ArrayList;

public class Compra extends AppCompatActivity {
    ListView listaCompras;
    ArrayList<String> lista;
    ArrayAdapter adaptador;

    @Override
    protected void onResume() {
        super.onResume();
        setContentView(R.layout.activity_compra);

        listaCompras = (ListView) findViewById(R.id.listaCompras);
        BaseDatos bd = new BaseDatos(getApplicationContext());
        lista = bd.datos_listAlbumes();
        adaptador = new ArrayAdapter(this, android.R.layout.simple_list_item_1, lista);
        listaCompras.setAdapter(adaptador);

        listaCompras.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> AdapterView, View view, int position, long l) {
                Intent intent = new Intent(Compra.this, Compra.class);
                intent.putExtra("NOMBRE", lista.get(position));
                startActivity(intent);
            }
        });
    }
}