package com.example.productos.Interface;

import com.example.productos.Models.Post;

import java.util.List;
import retrofit2.Call;
import retrofit2.http.GET;
import retrofit2.http.Query;

public interface ServicioPost {
    @GET("comments")
    Call<List<Post>> find(@Query("q")String q);
}
